package ChatApp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class ChatClient {
    private JFrame frame;
    private JTextArea chatArea;
    private JTextField inputField;
    private JButton sendButton;

    private PrintWriter out;

    public ChatClient(String serverAddress, int port) {
        try {
            // Connect to server
            Socket socket = new Socket(serverAddress, port);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);
            
            String username = JOptionPane.showInputDialog(frame, "Enter your name:");
            out.println("/name " + username);


            // --- GUI Setup ---
            frame = new JFrame("Chat Application");
            frame.setSize(400, 500);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            chatArea = new JTextArea();
            chatArea.setEditable(false);
            JScrollPane scrollPane = new JScrollPane(chatArea);

            inputField = new JTextField();
            sendButton = new JButton("Send");

            // Panel for input + button
            JPanel panel = new JPanel(new BorderLayout());
            panel.add(inputField, BorderLayout.CENTER);
            panel.add(sendButton, BorderLayout.EAST);

            frame.add(scrollPane, BorderLayout.CENTER);
            frame.add(panel, BorderLayout.SOUTH);

            // --- Event Handling ---
            // Send message on button click
            sendButton.addActionListener(e -> sendMessage());

            // Send message on ENTER key
            inputField.addActionListener(e -> sendMessage());

            frame.setVisible(true);

            // Thread to read messages from server
            new Thread(() -> {
                try {
                    String message;
                    while ((message = in.readLine()) != null) {
                        chatArea.append(message + "\n");
                    }
                } catch (IOException e) {
                    chatArea.append("Disconnected from server.\n");
                }
            }).start();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Method to send message
    private void sendMessage() {
        String message = inputField.getText().trim();
        if (!message.isEmpty()) {
            out.println(message); // send to server
            inputField.setText(""); // clear input box
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ChatClient("localhost", 1234));
    }
}
