package TicTacGame;

import java.util.Scanner;

public class TicTac {
    static char[][] board = {
            {' ', ' ', ' '},
            {' ', ' ', ' '},
            {' ', ' ', ' '}
    };

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        char currPlayer = 'X';
        boolean gameOver = false;

        System.out.println(" Starting the Game of TicTacToe ");
        printBoard();

        while (!gameOver) {
            System.out.println("Player " + currPlayer + " turn:");
            System.out.print("Enter row (0,1,2): ");
            int row = sc.nextInt();
            System.out.print("Enter col (0,1,2): ");
            int col = sc.nextInt();

            if (board[row][col] == ' ') {
                board[row][col] = currPlayer;
                printBoard();

                if (haveWon(currPlayer)) {
                    System.out.println("Player " + currPlayer + " wins!");
                    gameOver = true;
                } else if (isBoardFull()) {
                    System.out.println("Match is draw!");
                    gameOver = true;
                } else {
                    currPlayer = (currPlayer == 'X') ? 'O' : 'X';              // to switch the player, other player's turn now
                }

            } else {
                System.out.println("Cell is already taken! Try again.");
            }
        }

        sc.close();
    }

    public static void printBoard() {
        System.out.println("-------------");
        for (int i = 0; i < 3; i++) {
            System.out.print("| ");
            for (int j = 0; j < 3; j++) {
                System.out.print(board[i][j] + " | ");
            }
            System.out.println();
            System.out.println("-------------");
        }
    }

    public static boolean haveWon(char player) {
        for (int i = 0; i < 3; i++) {
            if (board[i][0] == player && board[i][1] == player && board[i][2] == player) {
                return true;
            }
        }
        for (int j = 0; j < 3; j++) {
            if (board[0][j] == player && board[1][j] == player && board[2][j] == player) {
                return true;
            }
        }
        if (board[0][0] == player && board[1][1] == player && board[2][2] == player) {
            return true;
        }
        if (board[0][2] == player && board[1][1] == player && board[2][0] == player) {
            return true;
        }
        return false;
    }

    public static boolean isBoardFull() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board[i][j] == ' ') {
                    return false;
                }
            }
        }
        return true;
    }
}
