package ToDoApp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ToDoApp extends JFrame {
	private DefaultListModel<String> taskListModel;
    private JList<String> taskList;
    private JTextField taskInput;
    
    public ToDoApp() {
    	// Set up the main window
        setTitle("To-Do List App");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); 
        
        // Panel for input and add button
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        // Input field for tasks
        taskInput = new JTextField();
        panel.add(taskInput, BorderLayout.CENTER);

        JButton addButton = new JButton("Add Task");
        panel.add(addButton, BorderLayout.EAST);
        
        taskListModel = new DefaultListModel<>();
        taskList = new JList<>(taskListModel);
        taskList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(taskList);

        JButton deleteButton = new JButton("Delete Task");

        add(panel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(deleteButton, BorderLayout.SOUTH);
        
        
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String task = taskInput.getText().trim();
                if (!task.isEmpty()) {
                    taskListModel.addElement(task);
                    taskInput.setText("");
                } else {
                    JOptionPane.showMessageDialog(null, "Enter a task");
                }
            }
        });

        // Event: Delete Task button
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedIndex = taskList.getSelectedIndex();
                if (selectedIndex != -1) {
                    taskListModel.remove(selectedIndex);
                } else {
                    JOptionPane.showMessageDialog(null, "Select a task to delete");
                }
            }
        });
        
        taskList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {  // Double-click
                    int index = taskList.locationToIndex(e.getPoint());
                    String task = taskListModel.getElementAt(index);
                    taskListModel.setElementAt(task + " ✅ (Completed)", index);
                }
            }
        });
    }
	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
            new ToDoApp().setVisible(true);
        });

	}

}
