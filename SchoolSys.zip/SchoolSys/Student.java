package SchoolSys;

public class Student {
	private String name;
	private int sub1;
	private int sub2;
	private int sub3;
	
	public Student(String name, int sub1, int sub2, int sub3) {
        this.name = name;
        this.sub1 = sub1;
        this.sub2 = sub2;
        this.sub3 = sub3;
    }
	
	public int Total() {
		return sub1+sub2+sub3;
	}
	
	public int Avg() {
		return Total()/3;
	}
	
	public String Grade() {
		double avg = Avg();
		if (avg>= 80) {
			return "A";
		}else if(avg >= 60 && avg < 80){
			return "B";
		}else if(avg >= 40 && avg < 60) {
			return "C";
		}else {
			return "Fail";
		}
	}
	
	public void Report() {
		System.out.println("Student Name: " + name);
        System.out.println("Subject 1: " + sub1);
        System.out.println("Subject 2: " + sub2);
        System.out.println("Subject 3: " + sub3);
        System.out.println("Total Marks: " + Total());
        System.out.println("Average Marks: " + Avg());
        System.out.println("Grade: " + Grade());
	}
}
