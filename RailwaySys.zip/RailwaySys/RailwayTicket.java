package RailwaySys;

import java.util.Scanner;

class Ticket {
    int ticketId;
    String passengerName;
    String trainName;
    String source;
    String destination;
    
    Ticket(int Id, String pName, String tName, String source, String destination) {
        this.ticketId = Id;
        this.passengerName = pName;
        this.trainName = tName;
        this.source = source;
        this.destination = destination;
    }
    
    void displayTicket() {
        System.out.println("\nTicket Details");
        System.out.println("Ticket ID: " + ticketId);
        System.out.println("Passenger Name: " + passengerName);
        System.out.println("Train Name: " + trainName);
        System.out.println("Source: " + source);
        System.out.println("Destination: " + destination);
    }
}

public class RailwayTicket {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Ticket ticket = null;
        int choice;
        int ticketCounter = 1;
        
        do {
            System.out.println("\nRailway Ticket Booking System");
            System.out.println("1. Book Ticket");
            System.out.println("2. Show Ticket");
            System.out.println("3. Cancel Ticket");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine();
        
            switch (choice) {
            case 1: // Book Ticket
                if (ticket != null) {
                    System.out.println("A ticket is already booked! Cancel it first.");
                    break;
                }
                System.out.print("Enter Passenger Name: ");
                String name = sc.nextLine();
                System.out.print("Enter Train Name: ");
                String train = sc.nextLine();
                System.out.print("Enter Source Station: ");
                String src = sc.nextLine();
                System.out.print("Enter Destination Station: ");
                String dest = sc.nextLine();

                ticket = new Ticket(ticketCounter++, name, train, src, dest);
                System.out.println("Ticket booked successfully!");
                break;

            case 2: // Show Ticket
                if (ticket == null) {
                    System.out.println("No ticket booked yet!");
                } else {
                    ticket.displayTicket();
                }
                break;

            case 3: // Cancel Ticket
                if (ticket == null) {
                    System.out.println("No ticket to cancel!");
                } else {
                    ticket = null;
                    System.out.println("Ticket cancelled successfully!");
                }
                break;

            case 4: // Exit
                System.out.println("Thank you for using the Railway Ticket Booking System!");
                break;

            default:
                System.out.println("Invalid choice! Please try again.");
        }

    } while (choice != 4);

    sc.close();
}
}