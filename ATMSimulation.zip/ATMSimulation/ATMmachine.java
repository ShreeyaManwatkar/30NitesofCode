package ATMSimulation;

import java.util.Scanner;

public class ATMmachine {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Initial data
        int pin = 1234;   // predefined PIN
        double balance = 10000.00;  // starting balance
        int enteredPin;
        int attempts = 0;
        boolean authenticated = false;

        // PIN Verification (max 3 attempts)
        while (attempts < 3) {
            System.out.print("Enter your 4-digit PIN: ");
            enteredPin = sc.nextInt();

            if (enteredPin == pin) {
                authenticated = true;
                System.out.println("PIN Verified Successfully!\n");
                break;
            } else {
                attempts++;
                System.out.println("Incorrect PIN. Attempts left: " + (3 - attempts));
            }
        }

        if (!authenticated) {
            System.out.println("Too many incorrect attempts. Card blocked!");
            sc.close();
            return;
        }

        // ATM Menu
        int choice;
        do {
            System.out.println("===== ATM MENU =====");
            System.out.println("1. Show Balance");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Your Balance: ₹" + balance);
                    break;

                case 2:
                    System.out.print("Enter amount to deposit: ₹");
                    double deposit = sc.nextDouble();
                    if (deposit > 0) {
                        balance += deposit;
                        System.out.println("₹" + deposit + " deposited successfully.");
                    } else {
                        System.out.println("Invalid deposit amount.");
                    }
                    break;

                case 3:
                    System.out.print("Enter amount to withdraw: ₹");
                    double withdraw = sc.nextDouble();
                    if (withdraw > 0 && withdraw <= balance) {
                        balance -= withdraw;
                        System.out.println("₹" + withdraw + " withdrawn successfully.");
                    } else {
                        System.out.println("Insufficient balance or invalid amount.");
                    }
                    break;

                case 4:
                    System.out.println("Thank you for using our ATM. Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice! Please try again.");
            }
            System.out.println();  // for spacing

        } while (choice != 4);

        sc.close();
    }
}
